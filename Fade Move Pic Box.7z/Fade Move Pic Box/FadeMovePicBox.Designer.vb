﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FadeMovePicBox
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.PicBox = New System.Windows.Forms.PictureBox()
        Me.MyTimer = New System.Windows.Forms.Timer(Me.components)
        CType(Me.PicBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PicBox
        '
        Me.PicBox.BackColor = System.Drawing.Color.Transparent
        Me.PicBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PicBox.Location = New System.Drawing.Point(0, 0)
        Me.PicBox.Name = "PicBox"
        Me.PicBox.Size = New System.Drawing.Size(133, 78)
        Me.PicBox.TabIndex = 0
        Me.PicBox.TabStop = False
        '
        'MyTimer
        '
        '
        'FadeMovePicBox
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Controls.Add(Me.PicBox)
        Me.Name = "FadeMovePicBox"
        Me.Size = New System.Drawing.Size(133, 78)
        CType(Me.PicBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PicBox As System.Windows.Forms.PictureBox
    Friend WithEvents MyTimer As System.Windows.Forms.Timer

End Class
