﻿Public Class FadeMovePicBox

    ' suggestion for FadeIn use Range of 15px and FadePerSec of 1.5
    ' suggestion for FadeIn use Range of 15px and FadePerSec of 5

    Enum FadeMode
        None = 0
        FadeIn = 1
        FadeOut = 2
    End Enum
    Enum MoveDirection
        None = 0
        Up = 1
        Down = 2
        Left = 3
        Right = 4
    End Enum

    Public Event ReadyToLaunch(ByVal sender As Object, ByVal e As EventArgs)
    Public Event FinishedLaunch(ByVal sender As Object, ByVal e As EventArgs)

    Dim MySWatch As Stopwatch
    Dim MyBitmap1 As Bitmap
    Dim MyBitmap2 As Bitmap
    
    Public RangeX As Integer
    Public RangeY As Integer

    Dim MovePerSec As Decimal
    Dim FadePerSec As Decimal

    Dim MyFadeMode As FadeMode
    Dim StartingOpacity As Decimal

    Dim TargetOpac As Decimal

    Property AttachedObject As Control

    ''' <summary> Default is None </summary>
    Property MyFadeModes As FadeMode
        Get
            Return MyFadeMode
        End Get
        Set(ByVal value As FadeMode)
            MyFadeMode = value
            Select Case MyFadeMode
                Case FadeMode.FadeIn
                    StartingOpacity = 0.0F
                    TargetOpac = 1.0F
                Case FadeMode.FadeOut
                    StartingOpacity = 1.0F
                    TargetOpac = 0.0F
            End Select
        End Set
    End Property
    ''' <summary> Default is None </summary>
    Property MyDirection As MoveDirection

    ''' <summary>
    ''' Movement Speed, Default is 30px per Second
    ''' </summary>
    Public Property MovePerSecond() As Decimal
        Get
            Return MovePerSec
        End Get
        Set(ByVal value As Decimal)
            MovePerSec = value / 1000
        End Set
    End Property

    ''' <summary>
    ''' Fade Speed Per Second, Default is 2 Opacity Fade per Second
    ''' </summary>
    Public Property FadePerSecond() As Decimal
        Get
            Return FadePerSec
        End Get
        Set(ByVal value As Decimal)
            FadePerSec = value / 1000
        End Set
    End Property

    Private Sub FadeMovePicBox_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BorderStyle = Windows.Forms.BorderStyle.None
        Me.DoubleBuffered = True

        MySWatch = New Stopwatch
        With MyTimer
            .Interval = 20
            .Enabled = False
        End With

        MovePerSecond = 20
        FadePerSecond = 5.0F
    End Sub

    Private Sub MyTimer_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyTimer.Tick
        Dim FadeRes As Boolean = False
        Dim MoveRes As Boolean = False

        Try
            If MyFadeModes <> FadeMode.None Then FadeRes = Fading()
            If MyDirection <> MoveDirection.None Then MoveRes = Moving()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        If Not FadeRes And Not MoveRes Then Stopping()
    End Sub

    ' ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ EVENT AND METHODS SEPARATOR ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ 

    ' Return a Bitmap holding an image of the control.
    Private Function GetControlImage(ByVal ctl As Control) As Bitmap
        Dim bm As New Bitmap(ctl.Width, ctl.Height)

        ctl.DrawToBitmap(bm, New Rectangle(0, 0, ctl.Width, ctl.Height))

        Return bm
    End Function
    ' Fade the bitmap
    Private Function FadeBitmap(ByVal bmp As Bitmap, ByVal opacity As Single) As Bitmap

        Dim bmp2 As New Bitmap(bmp.Width, bmp.Height, Imaging.PixelFormat.Format32bppArgb)

        Using ia As New Imaging.ImageAttributes

            Dim cm As New Imaging.ColorMatrix

            cm.Matrix33 = opacity
            ' set the ColorMatrix to IA
            ia.SetColorMatrix(cm)

            Dim destpoints() As PointF = {New Point(0, 0), New Point(bmp.Width, 0), New Point(0, bmp.Height)}

            Using g As Graphics = Graphics.FromImage(bmp2)
                ' draw image to bmp2's space
                g.DrawImage(bmp, destpoints, New RectangleF(Point.Empty, bmp.Size), GraphicsUnit.Pixel, ia)
            End Using

        End Using

        Return bmp2

    End Function

    ''' <summary>
    ''' Set The target object, and resetting all properties
    ''' </summary>
    Public Sub AttachTarget(ByVal Target As Control)
        ' reset
        AttachedObject = Nothing
        AttachedObject = Target
        With Target
            MyBitmap1 = GetControlImage(Target)
            MyBitmap2 = FadeBitmap(MyBitmap1, StartingOpacity)
            PicBox.Image = MyBitmap2
            Me.Location = .Location
            Me.Size = .Size
        End With
    End Sub

    Public Sub Launch()
        ' Preparing
        'PicBox.BackgroundImage = MyBitmap
        ' made visible above Targeted Object
        Me.Visible = True
        Me.BringToFront()
        ' Trigger Launch Event
        RaiseEvent ReadyToLaunch(AttachedObject, New EventArgs)
        ' Launch it !
        MySWatch.Start()
        MyTimer.Enabled = True
    End Sub

    Private Sub Stopping()
        ' Stop Timer !
        MyTimer.Enabled = False
        MySWatch.Stop()
        MySWatch.Reset()
        ' Trigger Launch Event
        RaiseEvent FinishedLaunch(AttachedObject, New EventArgs)
        ' made visible above Targeted Object
        Me.Visible = False
        Me.SendToBack()
        ' cleaning
        PicBox.Image = Nothing
    End Sub

    Private Function Fading() As Boolean
        Dim elapsedMilSec As Integer = MySWatch.ElapsedMilliseconds
        Dim NowOpac As Decimal

        ' calculate Opacity
        Select Case MyFadeModes
            Case FadeMode.FadeIn
                ' Fade In, increase from Starting Opacity
                NowOpac = (StartingOpacity + (FadePerSec * elapsedMilSec))
                ' check limit
                If NowOpac > TargetOpac Then NowOpac = TargetOpac
            Case FadeMode.FadeOut
                ' Fade Out, decrease from Starting Opacity
                NowOpac = (StartingOpacity - (FadePerSec * elapsedMilSec))
                ' check limit
                If NowOpac < TargetOpac Then NowOpac = TargetOpac
        End Select

        ' set to display
        MyBitmap2 = FadeBitmap(MyBitmap1, NowOpac)
        PicBox.Image = MyBitmap2

        If MyFadeModes = FadeMode.FadeIn And NowOpac = 1 Then
            Return False
        ElseIf MyFadeModes = FadeMode.FadeOut And NowOpac = 0 Then
            Return False
        End If

        Return True

    End Function

    Private Function Moving() As Boolean
        Dim elapsedMilSec As Integer = MySWatch.ElapsedMilliseconds
        Dim NowX As Decimal = Me.Location.X
        Dim NowY As Decimal = Me.Location.Y
        Dim ObjX As Integer = AttachedObject.Location.X
        Dim ObjY As Integer = AttachedObject.Location.Y

        ' calculate next location
        Select Case MyDirection

            Case MoveDirection.Up And MyFadeModes = FadeMode.FadeIn
                ' moving down
                NowY = (ObjY - RangeY) + (MovePerSec * elapsedMilSec)
                If NowY > ObjY Then NowY = ObjY : Return False
            Case MoveDirection.Up And MyFadeModes = FadeMode.FadeOut
                ' moving Up
                NowY = ObjY - (MovePerSec * elapsedMilSec)
                If NowY < (ObjY - RangeY) Then NowY = (ObjY - RangeY) : Return False

            Case MoveDirection.Down And MyFadeModes = FadeMode.FadeIn
                ' moving Up
                NowY = (ObjY + RangeY) - (MovePerSec * elapsedMilSec)
                If NowY < ObjY Then NowY = ObjY : Return False
            Case MoveDirection.Down And MyFadeModes = FadeMode.FadeOut
                ' moving down
                NowY = ObjY + (MovePerSec * elapsedMilSec)
                If NowY > (ObjY + RangeY) Then NowY = (ObjY + RangeY) : Return False

            Case MoveDirection.Left And MyFadeModes = FadeMode.FadeIn
                ' moving Right
                NowX = (ObjX - RangeX) + (MovePerSec * elapsedMilSec)
                If NowX > ObjX Then NowX = ObjX : Return False
            Case MoveDirection.Left And MyFadeModes = FadeMode.FadeOut
                ' moving Left
                NowX = ObjX - (MovePerSec * elapsedMilSec)
                If NowX < (ObjX - RangeX) Then NowX = (ObjX - RangeX) : Return False

            Case MoveDirection.Right And MyFadeModes = FadeMode.FadeIn
                ' moving Left
                NowX = (ObjX + RangeX) - (MovePerSec * elapsedMilSec)
                If NowX < ObjX Then NowX = ObjX : Return False
            Case MoveDirection.Right And MyFadeModes = FadeMode.FadeOut
                ' moving Right
                NowX = ObjX + (MovePerSec * elapsedMilSec)
                If NowX > (ObjX + RangeX) Then NowX = (ObjX + RangeX) : Return False
        End Select

        ' set location
        Me.Location = New Point(NowX, NowY)

        Return True

    End Function

End Class
